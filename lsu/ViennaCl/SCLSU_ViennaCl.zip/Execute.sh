./vienna ../../Cuprite/Cuprite ../OSP_IT_CUP ../Results/ResultsCuprite 0
